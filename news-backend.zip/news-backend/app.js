const express = require('express');
const mysql = require('mysql');
const cors = require('cors');
const app = express();
const port = 5000;
app.use(cors());
// MySQL kapcsolat beállítása
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'news_database'
});

// Kapcsolat megnyitása
db.connect(err => {
  if (err) {
    console.error('Hiba a MySQL kapcsolatban: ' + err.stack);
    return;
  }
  console.log('Sikeres MySQL kapcsolat, id: ' + db.threadId);
});

// GET végpont: Összes hír lekérdezése
app.get('/api/news', (req, res) => {
  const query = 'SELECT * FROM news';
  db.query(query, (err, results) => {
    if (err) {
      console.error('Hiba a lekérdezés során: ' + err.message);
      res.status(500).send('Internal Server Error');
      return;
    }
     // Kép konvertálása base64-be minden hír esetében
     const newsWithBase64Images = results.map(news => {
        return {
          ...news,
          news_pict: news.news_pict.toString('base64'),
        };
      });
  
      res.json(newsWithBase64Images);
    });
  });

// GET végpont: Egy hír lekérdezése adott news_id alapján
app.get('/api/news/:id', (req, res) => {
  const newsId = req.params.id;
  const query = 'SELECT * FROM news WHERE news_id = ?';
  db.query(query, [newsId], (err, results) => {
    if (err) {
      console.error('Hiba a lekérdezés során: ' + err.message);
      res.status(500).send('Internal Server Error');
      return;
    }
    if (results.length === 0) {
      res.status(404).send('Not Found');
      return;
    }
    const newsWithBase64Image = results.map(news => {
        return {
          ...news,
          news_pict: news.news_pict.toString('base64'),
        };
      });
      res.json(newsWithBase64Image[0]);
  });
});

// Szerver indítása
app.listen(port, () => {
  console.log(`A szerver fut a http://localhost:${port} címen.`);
});